<?php

/* @var $this yii\web\View */

$this->title = 'Tubes RPL 2018 fr';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>ABO</h1>

        <p class="lead">Aplikasi Beteng Online</p>

        <p><a class="btn btn-lg btn-success" href="http://localhost/advanced/frontend/web/index.php?r=produk">Get started</a></p>
    </div>

    
    
</div>
