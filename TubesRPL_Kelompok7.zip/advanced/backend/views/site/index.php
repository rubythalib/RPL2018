<?php

/* @var $this yii\web\View */

$this->title = 'Tubes RPL 2018';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>ABO Admin Control User</h1>

        <p class="lead">Admin Kingdom</p>

        <p><a class="btn btn-lg btn-success" href="http://localhost/advanced/backend/web/index.php?r=produk">Get started</a></p>
    </div>
</div>
