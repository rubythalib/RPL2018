<?php

Yii::setAlias('@imagePath','\var\www\html\advanced\image\\');
Yii::setAlias('@imageUrl','http://localhost/image');
return [
];
